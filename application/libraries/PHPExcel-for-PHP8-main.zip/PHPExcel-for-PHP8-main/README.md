﻿# PHPExcel-for-PHP8

----ENGLISH----
Partially fixed code to work on PHP8
Tested on PHP 8.1.6

Proven things that work properly:
-Simple generation of XLSX and XLS.
-Download via web and save as file.
-File Passwords.
-Autofilters.

XLS fails to generate with filters.
The use of the library, as well as its correct functionality in your project, is entirely your responsibility.

----ESPAÑOL----
Código parcialmente arreglado para trabajar en PHP8.
Probado en PHP 8.1.6

Cosas probadas que funcionan apropiadamente:
-Generación simple de XLSX y XLS.
-Descarga vía web y guardado como archivo.
-Contraseñas de archivo.
-Autofiltros.

XLS falla al generar con filtros.
El uso de la biblioteca, así como su correcta funcionalidad en tu proyecto, es responsabilidad totalmente tuya.
